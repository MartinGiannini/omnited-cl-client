import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { loginSuccess, logoutSuccess } from '../../store/authenticationSlice';
import { jwtDecode } from 'jwt-decode';
import useAuthService from '../../services/session/authentication/authentication';
import useCasService from '../../services/cas/cas.service';
 
const CasComponent = () => {
  const dispatch = useDispatch();
  const { getUsuario, getToken, storeToken, storeUsuario, storeRol, getRol, clearAuthentication } = useAuthService();
  const { login, logout } = useCasService();

  useEffect(() => {
    const token = getToken();
    
    if (!token) {
      const params = new URLSearchParams(window.location.search);
      const ticket = params.get('ticket');

      login(ticket)
        .then((response) => {
          const decoded = jwtDecode(response.data.token);
          
          storeUsuario(JSON.stringify(decoded['sub']).replace(/['"]+/g, ''));
          storeRol(JSON.stringify(decoded['role']).replace(/['"]+/g, ''));
          storeToken(response.data.token);
          
          dispatch(loginSuccess({
            usuario: decoded['sub'],
            token: response.data.token,
            rol: decoded['role'].replace(/['"]+/g, ''),
          }));
          
        })
        .catch((err) => {
          console.error('ERROR: ', err); 

          logout()
            .then((response) => {
              clearAuthentication();
              dispatch(logoutSuccess());
              window.location.href = response;
            })
            .catch((err) => {
              console.error('ERROR: ', err);
            });
        });
    } else {
      console.log('Usuario Logueado! Token correcto!');

      dispatch(loginSuccess({
        usuario: getUsuario().replace(/['"]+/g, ''),
        token: getToken(),
        rol: getRol(),
      }));
    }
  }, [storeToken, storeUsuario, storeRol, getUsuario, getToken, getRol, login, logout, dispatch]);
};

export default CasComponent;