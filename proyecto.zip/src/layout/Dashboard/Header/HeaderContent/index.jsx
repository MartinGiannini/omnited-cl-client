// material-ui
import useMediaQuery from '@mui/material/useMediaQuery';
import Box from '@mui/material/Box';

// project import
import Profile from './Profile';
import Notification from './Notification';
import MobileSection from './MobileSection';
import Phone from './Phone'
import WhatsApp from './WhatsApp';
import Messages from './Messages'
import States from './States';

// project import

import { WebRTCProvider } from '../../../../services/webrtc/webrtc.service';

// ==============================|| HEADER - CONTENT ||============================== //

export default function HeaderContent() {
  const downLG = useMediaQuery((theme) => theme.breakpoints.down('lg'));

  return (
    <>
      <WebRTCProvider>
        <States />
        <Phone />
        <WhatsApp />
      </WebRTCProvider>

      {downLG && <Box sx={{ width: '100%', ml: 1 }} />}
      <Messages />
      <Notification />
      {!downLG && <Profile />}
      {downLG && <MobileSection />}
    </>
  );
}
