import { configureStore } from '@reduxjs/toolkit';

import authenticationSlice from './store/authenticationSlice';
import notificationSlice from 'store/notificationSlice';
import websocketSlice from 'store/websocketSlice';
import userMessagesSlice from 'store/userMessagesSlice';
import userStatisticsSlice from 'store/userStatistics';
import webrtcSlice from 'store/webrtcSlice';
import userOptionsSlice from 'store/usersOptionsSlice';
import loggerMiddleware from './middleware/loggerMiddleware';

export const store = configureStore({
  reducer: {
    storeAuthentication: authenticationSlice,
    storeNotification: notificationSlice,
    storeWebsocket: websocketSlice,
    storeWebrtc: webrtcSlice,
    storeUserStatistics: userStatisticsSlice,
    storeUserMessages: userMessagesSlice,
    storeUserOptions: userOptionsSlice,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(loggerMiddleware),
});