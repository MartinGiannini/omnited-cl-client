import React, { useEffect, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import useWebSocket, { ReadyState } from 'react-use-websocket';
import { updateConnectionStatus, receiveMessage } from '../../store/websocketSlice';
import { setSendMessageFn } from '../../utils/websocketHelper';

const WS_URL = 'ws://localhost:8080/ws';

export default function WebSocketService() {
    const dispatch = useDispatch();

    // Configurar la conexión WebSocket
    const { sendMessage, lastMessage, readyState } = useWebSocket(WS_URL, {
        shouldReconnect: (closeEvent) => true,
        reconnectAttempts: 10,
        reconnectInterval: 3000,
    });

    // Almacenar sendMessage en el módulo auxiliar
    useEffect(() => {
        if (sendMessage) {
            setSendMessageFn(sendMessage);
        }
    }, [sendMessage]);

    // Heartbeat: enviar "ping" periódicamente para mantener la conexión activa
    useEffect(() => {
        const interval = setInterval(() => {
            if (readyState === ReadyState.OPEN) {
                sendMessage('ping');
            }
        }, 60000); // 30 segundos de intervalo

        return () => clearInterval(interval); // Limpiar el intervalo al desmontar
    }, [readyState, sendMessage]);

    // Actualizar el estado de la conexión en Redux
    useEffect(() => {
        const connectionStatus = {
            [ReadyState.CONNECTING]: 0,
            [ReadyState.OPEN]: 1,
            [ReadyState.CLOSING]: 2,
            [ReadyState.CLOSED]: 3,
            [ReadyState.UNINSTANTIATED]: 4,
        }[readyState];

        dispatch(updateConnectionStatus(connectionStatus));
    }, [readyState, dispatch]);

    // Manejar los mensajes recibidos y actualizarlos en Redux
    useEffect(() => {
        if (lastMessage !== null) {

            dispatch(receiveMessage(lastMessage.data));
        }
    }, [lastMessage, dispatch]);

    return
    <>
    //Nada
    </>;
}