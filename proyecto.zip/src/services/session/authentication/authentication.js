import { useState, useEffect } from 'react';

const useAuthService = () => {

  useEffect(() => {
    console.log('building auth');
  }, []);

  const storeToken = (token) => {
    sessionStorage.setItem('token', token);
  };

  const storeUsuario = (usuario) => {
    sessionStorage.setItem('usuario', usuario);
  };

  const storeRol = (rol) => {
    sessionStorage.setItem('rol', rol);
  };

  const getToken = () => {
    return sessionStorage.getItem('token');
  };

  const getUsuario = () => {
    return sessionStorage.getItem('usuario');
  };

  const getRol = () => {
    return sessionStorage.getItem('rol');
  };

  const clearAuthentication = () => {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('usuario');
    sessionStorage.removeItem('rol');
  }

  return {
    storeToken,
    storeUsuario,
    storeRol,
    getToken,
    getUsuario,
    getRol,
    clearAuthentication,
  };
};

export default useAuthService;