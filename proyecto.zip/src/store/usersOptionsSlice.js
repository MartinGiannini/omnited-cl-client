import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    wrapupTime: 10,
    estadoActual: 1,
    estadosStore: {
        1: 'Activo',
        2: 'Baño',
        3: 'Reunion',
        4: 'Forzada'
    },
};

const userOptionsSlice = createSlice({
    name: 'useroptions',
    initialState,
    reducers: {
        updateStates: (state, action) => {
            state.estadosStore = action.payload;
        },
        updateWrapup: (state, action) => {
            state.wrapupTime = action.payload;
        },
        updateEstadoActual: (state, action) => {
            state.estadoActual = action.payload;
        }
    },
});

export const { updateStates, updateWrapup, updateEstadoActual } = userOptionsSlice.actions;

export default userOptionsSlice.reducer;