import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  connectionStatus: 'No instanciado',
  lastMessage: null,
  messageHistory: [],
  sendMessage: ''
};

const websocketSlice = createSlice({
  name: 'websocket',
  initialState,
  reducers: {
    updateConnectionStatus: (state, action) => {
      state.connectionStatus = action.payload;
    },
    receiveMessage: (state, action) => {
      state.lastMessage = action.payload;
      state.messageHistory.push(action.payload);
    },
    sendMessageToStore: (state, action) => {
      state.messageHistory.push({ type: 'sent', message: action.payload });
    },
    clearMessageHistory: (state) => {
      state.messageHistory = [];
    },
  },
});

export const { updateConnectionStatus, receiveMessage, sendMessageToStore, clearMessageHistory } = websocketSlice.actions;

export default websocketSlice.reducer;