import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  isLoggedIn: false,
  usuario: null,
  token: null,
  rol: null,
};

const authenticationSlice = createSlice({
  name: 'authentication',
  initialState,
  reducers: {

    loginSuccess: (state, action) => {
      state.isLoggedIn = true;
      state.usuario = action.payload.usuario;
      state.token = action.payload.token;
      state.rol = action.payload.rol
    },

    logoutSuccess: (state) => {
      state.isLoggedIn = false;
      state.usuario = null;
      state.token = null;
      state.rol = null;
    },
  },
});

export const { loginSuccess, logoutSuccess } = authenticationSlice.actions;

export default authenticationSlice.reducer;