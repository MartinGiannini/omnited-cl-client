import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  uriStore: 'sip:mgiannini@192.168.0.100',
  serverStore: 'ws://192.168.0.100:8088/ws',
  dominioStore: '192.168.0.100',
  connectionStatus: 0, //Desconectado
};

/*
0 => Desconectado
1 => Conectado
2 => Llamada Ringueando
3 => Llamada Establecida
4 => Llamada Holdeada
5 => ¿?
*/

const webrtcSlice = createSlice({
  name: 'webrtc',
  initialState,
  reducers: {
    updateConnectionStatus: (state, action) => {
      state.connectionStatus = action.payload;
    },
  },
});

export const { updateConnectionStatus } = webrtcSlice.actions;

export default webrtcSlice.reducer;